// Netlify serverless function — runs on Netlify's servers, never in the browser.
// This is the piece that actually talks to Stripe with your secret key.
// It creates a Stripe-hosted Checkout Session and hands back the URL to redirect to.
//
// Requires the STRIPE_SECRET_KEY environment variable to be set in the
// Netlify dashboard (Site settings -> Environment variables). Never put
// your secret key directly in this file or commit it to a public repo.

const Stripe = require('stripe');

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  if (!process.env.STRIPE_SECRET_KEY) {
    console.error('STRIPE_SECRET_KEY is not set in the environment.');
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Payments are not configured yet on the server.' }),
    };
  }

  const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

  try {
    const { items, customerEmail } = JSON.parse(event.body || '{}');

    if (!Array.isArray(items) || items.length === 0) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Your bag is empty.' }) };
    }

    // Rebuild line items server-side from name/size/price sent by the browser.
    // In a more advanced version you'd look prices up from a trusted source
    // (e.g. a products file or database) instead of trusting the client, so a
    // tampered request can't check out at a lower price than intended.
    const line_items = items.map((item) => ({
      price_data: {
        currency: 'gbp',
        product_data: {
          name: `${item.product} (Size ${item.size})`,
        },
        unit_amount: Math.round(Number(item.price) * 100),
      },
      quantity: 1,
    }));

    const siteUrl = process.env.URL || 'http://localhost:8888';

    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      payment_method_types: ['card'],
      line_items,
      customer_email: customerEmail || undefined,
      shipping_address_collection: {
        allowed_countries: ['GB', 'IE', 'US', 'CA', 'AU', 'FR', 'DE', 'ES', 'IT', 'NL'],
      },
      success_url: `${siteUrl}/success.html?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${siteUrl}/cancel.html`,
    });

    return {
      statusCode: 200,
      body: JSON.stringify({ url: session.url }),
    };
  } catch (err) {
    console.error('Stripe checkout session error:', err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Could not start checkout. Please try again.' }),
    };
  }
};
